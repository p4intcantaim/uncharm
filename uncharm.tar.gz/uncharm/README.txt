Do you hate it when you open pycharm and you see that some ".lock" file was created, preventing you from opening pycharm. So you have to go all the way to the ".lock" files location and delete it?

Well, this script is the solution!
All you have to do is run the installer and it will say that it installed, then any time that annoying message shows up close out of it and go into a terminal and type "uncharm" (Type it without the quotation marks.) then reopen pycharm and BOOM! You're done! From now on you only have to type "uncharm" (Type it without the quotation marks.) in a terminal and it removes the lock.

--------------------------------------------------------

Created by: p4int

My Github:
https://github.com/p4intcantaim
